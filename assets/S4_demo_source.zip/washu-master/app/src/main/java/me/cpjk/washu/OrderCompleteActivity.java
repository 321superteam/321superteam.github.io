package me.cpjk.washu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OrderCompleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_complete);
    }
}
