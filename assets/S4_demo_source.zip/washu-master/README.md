# washu

:potable_water::potable_water::potable_water::moneybag::moneybag::moneybag::moneybag:

**This is a prototype put together quickly for a class demonstration. The code is terrible, but remains here for posterity. Copying any of this code is not recommended.**
